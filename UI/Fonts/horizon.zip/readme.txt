Free for personal and commercial use

This is my biggest tipography project to date. My goal was to create a display font that combines traditional elements with elements of experimental typography. In my opinion, this font is a display font. Inspired by the VHS tapes and promotional materials of the 70s and 80s, the font contains postmodern elements and makes it really interesting to me.

Pay what you like:
https://payhip.com/b/qPLe

Follow:
https://www.behance.net/kotelestm
http://instagram.com/koteles.tm

More projects:
https://kotelestm.com/